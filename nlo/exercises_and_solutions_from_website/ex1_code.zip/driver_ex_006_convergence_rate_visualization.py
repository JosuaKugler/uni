showFigs = True
# This script visualizes the set of M-gradients with corresponding half space of descent directions

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True

import numpy as np
from scipy.special import factorial
import matplotlib.pyplot as plt

# functions for sequences
f_sublinear = lambda k: 1/k
f_linear = lambda k,q: q**k
f_suplinear = lambda k: 1/factorial(k)
f_higherOrder = lambda k, q, alpha: q**(alpha**k)

# sequence labels
sequenceLabels = [r'$\frac{1}{k}$ (sublinear)', r'$q^k$ (linear)', r'$\frac{1}{k!}$ (superlinear)', r'$q^{(2^k)}$ (quadratic)']

# sequence parameter
q = 0.5

# number of sequence elements to plot (needs a short one because quadratic is super fast and overflows)
nLong = 150
nShort = 60

# get sequences and iterates
sequences = []
ks = []
ks.append(np.arange(nLong)+1)
sequences.append(f_sublinear(ks[-1]))

ks.append(np.arange(nLong)+1)
sequences.append(f_linear(ks[-1], q))

ks.append(np.arange(nLong)+1)
sequences.append(f_suplinear(ks[-1]))

ks.append(np.arange(nShort)+1)
sequences.append(f_higherOrder(ks[-1], q, 2))

# How many subplots
rows = 2
cols = len(sequences)

# Create figure
fig, ax = plt.subplots(rows, cols, figsize = (18,10))

# start iterating for plots
for i, (k, x) in enumerate(zip(ks,sequences)):
	# linear plots
	ax = plt.subplot(rows, cols, 1 + i)
	plt.plot(k, x)
	ax.set_title(sequenceLabels[i])

	# logged plots
	ax = plt.subplot(rows, cols, 1 + cols + i)
	plt.semilogy(k, x)
	ax.set_xlabel('iteration k')

# Add some labels
ax = plt.subplot(rows, cols, 1)
ax.set_ylabel('Linear plots')

ax = plt.subplot(rows, cols, 1 + cols)
ax.set_ylabel('Semilog plots')

# save figure
if saveFigs:
	figName = '../figures/ex_006_convergence_rate_plot_comparison.png'
	print('driver_ex_006 is saving figure: ' + figName)
	plt.savefig(figName)

# Add some alpha polynomial plots
plt.figure(figsize=(8,8))

ksShort = np.arange(nShort)+1
alphas = np.linspace(1,2,8)[1:]

for alpha in alphas:
	plt.semilogy(ksShort, f_higherOrder(ksShort,q,alpha))

plt.legend([r'$\alpha$ = ' + '{:1.2f}'.format(alpha) for alpha in alphas])
plt.title(r'Lower ($\alpha$) order convergence')

if saveFigs:
	figName = '../figures/ex_006_convergence_order_comparison.png'
	print('driver_ex_006 is saving figure: ' + figName)
	plt.savefig(figName)

try:
	if showFigs:
		plt.show()
except:
	pass
