showFigs = True
# This script visualizes and compares the convergence behavior of the steepest descent methods and the conjugate gradient method (both with Cauchy step size) for spd quadratic optimization problems
# Comparisons:
# 1: 2-d problem that was used in the examination of the steepest descent behavior
# 2: Randomized 100-d problem with kappa = 100
# 3: Two 20-d problems with (non-) clustered eigenvalues

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True

import numpy as np
from cg_quadratic import *
from scipy.linalg import eigh
from scipy.stats import ortho_group
from step_length_rules_quadratic import *
from visualization_functions import plot_2d_iterates_contours, plot_f_val_diffs, plot_step_sizes, plot_grad_norms
import matplotlib.pyplot as plt
## Test 1, compare solvers in 2d
# Set quadratic function data
A = np.array([[4.0, -1.25], [-1.25, 1.0]])
b = np.array([2.0,0])
c = 0

# Make quadratic function
f = lambda x: 0.5*x.T@(A@x) - b@x + c

# Set an arbitrary initial point that may be used
x0 = (2.0, 5.0)

# Set plotting upper and lower bounds
xlims = (-2.5,5.5)
ylims = (-2.5,5.5)

# Set diagonal preconditioner
preconditioner = np.diag(np.diag(A))

# Set algorithmic parameters
options = {
	"atol_res": 5e-8,
	"rtol_res": 5e-8,
	"max_iterations" : 1e4,
	#"verbosity" : "verbose",
	"verbosity" : "quiet",
	"keep_history" : True,
	"reset_after" : 50
}

# Compute reference solution
reference_sol = np.linalg.solve(A,b)
reference_value = f(reference_sol)

# save eigenvalue data
generalized_eigenvalues = eigh(A, preconditioner, eigvals_only = True)
generalized_condition_numbers=[generalized_eigenvalues[-1] / generalized_eigenvalues[0]]*2

# Compare both solvers in 2d
options.update({'conjugate': False})
gd_sol = cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A, b, c, x0, options = options)
options.update({'conjugate': True})
cg_sol = cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A, b, c, x0, options = options)

outputs = [cg_sol,gd_sol]
labels = ['CG','SD']

# Plot preconditioner history in iterate space
iterFig = plot_2d_iterates_contours(f, histories = list(out["history"] for out in outputs), labels = labels, title = 'Comparison of CG and SD in Iterate Space', xlims = xlims, ylims = ylims)

# Plot error energy norm
convFig = plot_f_val_diffs(list(out["history"] for out in outputs),
				[reference_value] * len(outputs),
				generalized_condition_numbers,
				methods = ['CG','SD'],
				labels = labels,
				title = 'Convergence comparison')

# Save figures
if saveFigs:
	for fig, name in zip([iterFig, convFig],['iterates_2d', 'convergence_2d']):
		figName = '../figures/ex_010_cg_sd_comparison_' + name + '.png'
		print('driver_ex_010 is saving figure: ' + figName)
		plt.figure(fig)
		plt.savefig(figName)

## Test 2, pseudo randomly generated spd Matrix in R^100 of condition number 100
np.random.seed(seed=0)

# Make eigenvalues in [1,100]
dim = 100
eigs = np.sort(np.random.rand(dim)*(dim-1)+1)
eigs[0], eigs[-1] = 1, dim

# Get random orthogonal matrix
V = ortho_group.rvs(dim = dim)

# Construct quadratic function data
A = V.T @ np.diag(eigs) @ V
b = np.zeros(dim)
c = 0

# Set number of x0 samples
nSamples = 3

# Set solver options
options = {
	"atol_res": 5e-8,
	"rtol_res": 5e-8,
	"max_iterations" : 1e4,
	#"verbosity" : "verbose",
	"verbosity" : "quiet",
	"keep_history" : True,
	"reset_after" : 50
}

# Set Preconditioner
preconditioner = np.diag(np.diag(A))

# Create a new container
SD_outputs = []
CG_outputs = []

# Set box to draw the initial values from
l, u = -3, 3

for i in np.arange(nSamples):
	x0 = (u-l)*np.random.random_sample(dim) + l

	# Solve problem using both solvers
	options.update({'conjugate': False})
	SD_outputs.append(
		cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A, b, c, x0, options = options)
		)
	options.update({'conjugate': True})
	CG_outputs.append(
		cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A, b, c, x0, options = options)
	)

convFigs = []

for outputs, title, methods, labels in zip([CG_outputs+SD_outputs,CG_outputs], ['Convergence CG/SD','Convergence CG'], [['CG']*nSamples+['SD']*nSamples,['CG']*nSamples], [['CG']*nSamples+['SD']*nSamples,['CG']*nSamples]):
	convFigs.append(plot_f_val_diffs(list(out["history"] for out in outputs),
				reference_values = np.array([0] * len(outputs)),
				condition_numbers = [100]*len(outputs),
				methods = methods,
				labels = labels,
				title = title))

# save plots
if saveFigs:
	for fig, name in zip(convFigs,['convergence_CGSD','convergence_CG']):
		figName = '../figures/ex_010_cg_sd_comparison_d=100_' + name + '.png'
		print('driver_ex_010 is saving figure: ' + figName)
		plt.figure(fig)
		plt.savefig(figName)

### Test 3 - eigenvalue clustering
# Reset random numbers
np.random.seed(seed=0)

# Make clustered eigenvalues in [1,100]
num_clusters = 2
d_clusters = 50
eigs_per_cluster = d_clusters
dim = num_clusters * d_clusters
cluster_spans = [1,2,8]

# Make equidistantly distributed eigenvalues between the first cluster location and dim
equidist_eigs = np.linspace(d_clusters,dim,dim)

# Get random orthogonal matrix
V = ortho_group.rvs(dim = dim)

# Construct quadratic function data
A_equi = V.T @ np.diag(equidist_eigs) @ V

b = np.zeros(dim)
c = 0

# Set solver options
options = {
	"atol_res": 5e-8,
	"rtol_res": 5e-8,
	"max_iterations" : 1e4,
	#"verbosity" : "verbose",
	"verbosity" : "quiet",
	"keep_history" : True,
	"reset_after" : 50,
	'conjugate': True
}


# Set Preconditioner
#preconditioner = np.diag(np.diag(A))
preconditioner = np.eye(dim)

# Set box to draw the initial value from
l, u = -3, 3

# Random initial value
x0 = (u-l)*np.random.random_sample(dim) + l

cluster_outputs = []

equi_output = cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A_equi, b, c, x0, options = options)

for cluster_span in cluster_spans:
	# Make clusters
	cluster_locations = d_clusters*(np.arange(num_clusters)+1)
	clustered_eigs = np.concatenate([np.array((np.random.rand(eigs_per_cluster)-0.5)*cluster_span+cluster_location) for cluster_location in cluster_locations])
	
	A_clus = V.T @ np.diag(clustered_eigs) @ V

	# Solve problems using CG
	cluster_outputs.append(cg_quadratic(lambda r: np.linalg.solve(preconditioner,r), A_clus, b, c, x0, options = options))
	
plot_f_val_diffs(list(out["history"] for out in cluster_outputs+[equi_output]),
					reference_values = np.array([0] * (len(cluster_spans)+1)),
					labels = ['Clustered span = {:d}'.format(cluster_span) for cluster_span in cluster_spans] + ['Equidistant eigenvalues'],
					title = 'Clustering behavior of CG for dim = {:d}'.format(dim))
	
if saveFigs:
	figName = '../figures/ex_010_cg_clustering_behavior.png'
	print('driver_ex_010 is saving figure: ' + figName)
	plt.savefig(figName)

try:
	if showFigs:
		plt.show()
except:
	pass
