showFigs = True
# This script visualizes the Delta families of solutions to trust region subproblems for Rosenbrock's function

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True

import numpy as np
import scipy.optimize
import matplotlib.pyplot as plt
from objective_functions import *

plt.rcParams["figure.figsize"] = (10,10)

# Set Rosenbrock function parameters
a = 1
b = 10

# Construct Rosenbrock function
rBrock = lambda x, derivatives: rosenbrock(x, derivatives, {'a': a, 'b': b})

# Set bounding box that we're interested in for plotting later on
xlims = (-2,2)
ylims = (-2,2)

# Number of discretization points per dimension
nd = 301

# Set discretization of iterate space for contour plots
x_disc = np.linspace(xlims[0], xlims[1], num = nd)
y_disc = np.linspace(ylims[0], ylims[1], num = nd)
X, Y = np.meshgrid(x_disc, y_disc)

# Get the function values of rosenbrock function on the grid for contour plots
ZRBrock = np.zeros(X.shape)
for i, x_comp in enumerate(x_disc):
	for j, y_comp in enumerate(y_disc):
		ZRBrock[i,j] = rBrock(np.array([x_comp,y_comp]),[True,False,False])["function"]
ZRBrockmin = ZRBrock.min()
ZRBrockmax = ZRBrock.max()

# Set levels for rosenbrock contour plot
RBrockLevels = ZRBrockmin + (((np.linspace(ZRBrockmin,ZRBrockmax,20)-ZRBrockmin)/(ZRBrockmax-ZRBrockmin))**6)*(ZRBrockmax-ZRBrockmin)

# Set radii for bounds
maxDelta = 2
deltas = np.linspace(1e-6,maxDelta,100)

# Which Deltas to plot the trust region for
nPlotDeltas = 3
plotDeltas = [deltas[int(np.floor((i+1)*len(deltas)/nPlotDeltas))-1] for i in range(nPlotDeltas) ]

# List of points that we want to draw visualizations for
xList = [np.array((0,-1)), np.array((0,0.5))]

# Fix a reference preconditioner/norm
M = np.eye(2)
Mnorm2 = lambda s: s.T.dot(M@s)
dMnorm2 = lambda s: 2*M@s
Mnorm = lambda s: np.sqrt(Mnorm2(s))

# Draw visualizations for every point specified in the list
for x in xList:

	# get model data for quadratic models
	rBrockValues = rBrock(x, [True, True, True])

	# choose two model hessians
	for H, name in zip([np.eye(2), rBrockValues['Hessian']], ['Euclidean','Hessian']):

		# Open a figure
		fig, ax = plt.subplots()

		# Plot rosenbrock contours
		plt.contourf(X, Y, (ZRBrock).T, cmap='gray_r', levels = RBrockLevels, alpha = 0.4)
		plt.contour(X, Y, (ZRBrock).T, colors='k', levels = RBrockLevels, alpha = 0.4)

		# build quadratic model
		quadModel= lambda s, derivatives: quadratic_function(
			s,
			derivatives,
			H,
			rBrockValues['derivative'],
			rBrockValues['function']
		)

		# Compute model values for contour plot
		ZQ = np.zeros(X.shape)
		for i, x_comp in enumerate(x_disc):
			for j, y_comp in enumerate(y_disc):
				ZQ[i,j] = quadModel(np.array([x_comp,y_comp])-x,[True,False,False])["function"]
		ZQmin = ZQ.min()
		ZQmax = ZQ.max()

		# Set levels for model contour plot
		quadLevels = ZQmin + (((np.linspace(ZQmin,ZQmax,20)-ZQmin)/(ZQmax-ZQmin))**3)*(ZQmax-ZQmin)

		# Set up initial guess for nonlinear solver
		initialGuess = np.zeros(2)

		# Initialize minimizer container
		minimizers = []
		plotMinimizers = []

		for delta in deltas:
			# Set up trust region constraint
			trustRegionConstraint = scipy.optimize.NonlinearConstraint(
								fun = Mnorm2,
								jac = dMnorm2,
								lb = -np.inf,
								ub = delta**2
							)

			# Solve subproblem using constrained optimization solver
			subproblemResult = scipy.optimize.minimize(
				fun = lambda s: quadModel(s, [True, False, False])['function'],
				x0 = initialGuess,
				jac = lambda x: quadModel(x, [False, True, False])['derivative'],
				constraints = trustRegionConstraint,
				method = 'SLSQP',
				options = {'disp':False}
			)

			# Use previous solution as upcoming initial guess
			initialGuess = subproblemResult.x

			# Remember the minimizer
			minimizers.append(subproblemResult.x)

			if delta in plotDeltas:
				plotMinimizers.append(subproblemResult.x)

		# Plot quadratic model contours
		plt.contour(X, Y, (ZQ).T, colors='r', levels = quadLevels, alpha = 1)

		# Plot line of minimizers corresponding to various deltas
		plt.plot([x[0] + minim[0] for minim in minimizers], [x[1] + minim[1] for minim in minimizers],'b')

		# plot the point x
		plt.plot(x[0], x[1], 'bo', linewidth=1, markersize=8)

		# Compute M norm values for contour plot
		ZM = np.zeros(X.shape)
		for i, x_comp in enumerate(x_disc):
			for j, y_comp in enumerate(y_disc):
				ZM[i,j] = Mnorm(np.array([x_comp,y_comp])-x)
		ZMmin = ZM.min()
		ZMmax = ZM.max()

		# Set levels of M norm for plotting contours
		MLevels = plotDeltas

		# Plot quadratic model contours
		plt.contour(X, Y, (ZM).T, colors='b', levels = MLevels, alpha = 0.5, linestyles = 'dashed')

		# plot points on line of delta solutions
		plt.plot([x[0] + minim[0] for minim in plotMinimizers], [x[1] + minim[1] for minim in plotMinimizers],'bx', linewidth=1, markersize=8)

		ax.set_aspect('equal', 'box')
		
		plt.title(f'Subproblem minimizers for {name} model at ({x[0]},{x[1]})')
		plt.xlabel(r'$x_1$')
		plt.ylabel(r'$x_2$')

		if saveFigs:
			figName = f'../figures/ex_025_trust_region_subproblem_visualization_{x[0]}_{x[1]}_{name}.png'
			print('driver_ex_025 is saving figure: ' + figName)
			plt.savefig(figName)
		
		#Plot the gradients of q and the constraint 0.5(norm(s)_M^2 - Delta^2) to show that they are actually antiparallel
		for s in plotMinimizers:
			# Evaluate the derivative of the quadratic model (only because M = id) for the gradient
			modelGradient = quadModel(s, [False, True, False])['derivative']

			# Evaluate Ms
			Ms = M@(s)

			for g in [modelGradient, Ms]:
				# Plot the gradients
				plt.arrow(*(x+s), *(5e-1*g/Mnorm(g)), head_width=0.05, length_includes_head=True)

		if saveFigs:
			figName = f'../figures/ex_025_trust_region_subproblem_visualization_{x[0]}_{x[1]}_{name}_gradients.png'
			print('driver_ex_025 is saving figure: ' + figName)
			plt.savefig(figName)

		# Open another figure for the x/y plots
		fig, ax = plt.subplots()
		
		plt.plot(deltas, [minim[0] for minim in minimizers], label=r'$x_1$')
		plt.plot(deltas, [minim[1] for minim in minimizers], label=r'$x_2$')
		plt.xlabel(r'$\Delta$')
		plt.legend()
		
		if saveFigs:
			figName = f'../figures/ex_025_trust_region_subproblem_visualization_{x[0]}_{x[1]}_{name}_locations.png'
			print('driver_ex_025 is saving figure: ' + figName)
			plt.savefig(figName)

try:
	if showFigs:
		plt.show()
except:
	pass
