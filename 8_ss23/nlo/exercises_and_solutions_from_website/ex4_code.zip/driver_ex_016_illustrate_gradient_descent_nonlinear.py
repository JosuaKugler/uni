showFigs = True
# This script visualizes the behavior of various step length rules in 
# the preconditioned gradient descent method. The goal is to show the influence
# of the Armijo line search parameters, and their impact on the zig-zagging
# behavior of gradient descent for a quadratic objective.

# Decide whether figures are to be shown or saved
try:
	if showFigs:
		saveFigs = False
	else:
		saveFigs = True
except:
		saveFigs = True

import numpy as np
from gradient_descent_nonlinear import *
from objective_functions import *
from step_length_rules_nonlinear import *
from visualization_functions import *
from operator import itemgetter

plt.rcParams["figure.figsize"] = (10,10)

def get_configuration(configurationName):
	# Return configurations to investigate
	match configurationName:
		case 'quadratic':			
			# Set problem data
			A = np.array([[10.0, -2.0], [-2.0, 1.0]])
			b = np.array([2.0,0.0])
			c = 0

			# Set function
			fun = lambda u, derivatives: quadratic_function(u, derivatives, A, b, c)
			
			# Set bounding box that we're interested in
			xlims = (-3,3)
			ylims = (-3,3)
			
			# Compute reference solution
			reference_sol = np.array(np.linalg.solve(A,-b))
			reference_value = fun(reference_sol, [True, False, False])['function']
			
		case 'rosenbrock':
			# Set problem parameters
			a = 1
			b = 10

			# Construct function
			fun = lambda x, derivatives: rosenbrock(x, derivatives, {'a': a, 'b': b})

			# Set bounding box that we're interested in
			xlims = (-2,2)
			ylims = (-2,2)

			# Compute reference solution
			reference_sol = np.array([1.0,1.0])
			reference_value = fun(reference_sol, [True, False, False])['function']
			
		case _:
			print('<<<<<<< Unknown configuration name >>>>>>>')
			sys.exit()
					
		# Reset random number generator
	np.random.seed(0)		

	# Save data for pseudo randomized initial values
	nSamples = 4
	dim = 2
	
	# Generate random initial guesses
	x0s = []
	for i in np.arange(nSamples):
		x0s.append(
			np.array(
				[
					(xlims[1]-xlims[0])*np.random.random_sample() + xlims[0],
					(ylims[1]-ylims[0])*np.random.random_sample() + ylims[0]
				]
			)
		)
				
	configuration = {
			'fun': fun,
			'xlims': xlims,
			'ylims': ylims,
			'reference_value': reference_value,
			'x0s': x0s,
			'configurationName': configurationName
		}
		
	return configuration

# Set parameters for the Armijo linesearch
armijo_parameters = {
    "initial_step_length" : 5.0,
    #"verbosity" : "verbose"
    }

# Set the parameters for the gradient descent method
optimization_parameters = {
	"atol_f" : 1e-10,
	"rtol_f" : 1e-10,
	"atol_gradf" : 1e-10,
	"rtol_gradf" : 1e-10,
	"max_iterations" : 1e4,
	"c" : 10,
	#"verbosity" : "verbose",
	"keep_history" : True
}

# construct step length rule
armijo_step_length_rule = lambda phi, reusables: armijo_backtracking(phi, reusables, parameters = armijo_parameters)

# construct a preconditioner
Pinv = lambda r: r # euclidean
#Pinv = lambda r: np.linalg.solve(np.diag(np.diag(A)), r) # euclidean

# Fix various betas and sigmas
betas = [0.01, 0.5, 0.99]
sigmas = [1e-2, 0.3, 0.7]
	
	
for configuration in [get_configuration(configurationName) for configurationName in ['quadratic', 'rosenbrock']]:
	fun, xlims, ylims, x0s, reference_value, configurationName = itemgetter('fun', 'xlims', 'ylims', 'x0s', 'reference_value', 'configurationName')(configuration)
	
	# Loop over all armijo parameters and all random starting points, solve and visualize
	for beta in betas:
		for sigma in sigmas:
			# Solve problem starting from various initial values
			outputs = []
			
			armijo_parameters['betas'] = [beta]
			armijo_parameters['sigma'] = sigma

			for x0 in x0s:
				# Solve the problem using the gradient scheme with armijo step lengths
				outputs.append(gradient_descent_nonlinear(fun, x0, armijo_step_length_rule, Pinv, optimization_parameters))

			labels = None
			title = f'beta = {beta}, sigma = {sigma}'

			# Plot the iterates
			iterFig = plot_2d_iterates_contours(lambda x: fun(x, [True, False, False])['function'], histories = list(out["history"] for out in outputs), labels = labels, title = title, xlims = xlims, ylims = ylims)

			# Plot error energy norm
			convFig = plot_f_val_diffs(list(out["history"] for out in outputs),
			[reference_value] * len(outputs),
			labels=labels,
			title = title)		

			if saveFigs:
				for fig, name in zip([iterFig, convFig], ['iterates', 'convergence']):
					plt.figure(fig)
					figName = '../figures/ex_016_{:s}_{:s}_{:1.2f}_{:1.2f}.png'.format(configurationName,name,beta,sigma)
					print('driver_ex_016 is saving figure: ' + figName)
					plt.savefig(figName)
					plt.close()

try:
	if showFigs:
		plt.show()
except:
	pass
