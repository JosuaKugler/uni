# This module collects implementations for various objective functions 
# f: R^n -> R useful to test optimization procedures.

import numpy as np

def quadratic_function(x, derivatives, Q, c, gamma):
	"""
	Evaluate the quadratic function 

		1/2 x'Qx + c'x + gamma 

	and its derivatives.

	Accepts:
	            x: point of evaluation (list or numpy array with ndim == 1)
	  derivatives: Boolean list of length 3 indicating which derivatives
	               (orders 0-2) should be returned; e.g., [True, True, False]
	            Q: symmetric numpy array with ndim == 2
	            c: numpy array with ndim == 1
	        gamma: scalar

	Returns:
		       values: dictionary containing the evaluations of the function
		               and its first and second derivatives as required, with
		               keys ["function"], ["derivative"] and ["Hessian"]
	"""
	values = {}
	if derivatives[0]:
		values["function"] = 0.5 * x.dot(Q.dot(x)) + c.dot(x) + gamma
	if derivatives[1]:
		values["derivative"] = Q.dot(x) + c
	if derivatives[2]:
		values["Hessian"] = Q
  
	return values

def himmelblau(x, derivatives):
	"""
	Evaluate Himmelblau's function 
	
		f(x) = (x[0]^2+x[1]-11)^2 + (x[0]+x[1]^2-7)^2 
	
	and its derivatives.

	Accepts:
	                   x: point of evaluation (list or numpy array with ndim == 1)
	         derivatives: Boolean list of length 3 indicating which derivatives
                 (orders 0-2) should be returned; e.g., [True, True, False]

	Returns:
	         values: dictionary containing the evaluations of the function
	                 and its first and second derivatives as required, with
	                 keys ["function"], ["derivative"] and ["Hessian"]
	"""
	values = {}
	if derivatives[0]:
		values["function"] = (x[0]**2 + x[1] - 11)**2 + (x[0] + x[1]**2 - 7)**2
	if derivatives[1]:
		values["derivative"] = np.array([\
			2 * (-7 + x[0] + x[1]**2) + 4 * x[0] * (-11 + x[0]**2 + x[1]),\
			4 * x[1] * (-7 + x[0] + x[1]**2) + 2 * (-11 + x[0]**2 + x[1])\
		])
	if derivatives[2]:
		values["Hessian"] = np.array([\
			[4 * (-11 + x[0]**2 + x[1]) + 8 * x[0]**2 + 2, 4 * x[1]+4 * x[0]],\
			[4 * x[1] + 4 * x[0], 4 * (-7 + x[0] + x[1]**2) + 8 * x[1]**2 + 2]\
		])
    
	return values

def rosenbrock(x, derivatives, parameters = {}):
	"""
	Evaluate the Rosenbrock function 

		f(x) = (a-x)^2 + b(y-x^2)^2

	and its derivatives.

	Accepts:
		                 x: point of evaluation (list or numpy array with ndim == 1)
		       derivatives: Boolean list of length 3 indicating which derivatives
		                    (orders 0-2) should be returned; e.g., [True, True, False]
		        parameters: optional parameters (dictionary);
		                    the following key/value pairs are evaluated:
		             ["a"]: parameter 1
		             ["b"]: parameter 2

	Returns:
		       values: dictionary containing the evaluations of the function
		               and its first and second derivatives as required, with
		               keys ["function"], ["derivative"] and ["Hessian"]
	"""
  
	a = parameters.get("a", 1)
	b = parameters.get("b", 100)
  
	values = {}
	if derivatives[0]:
		values["function"] = (a-x[0])**2 + b*(x[1]-x[0]**2)**2
	if derivatives[1]:
		values["derivative"] = np.array([\
			-2 * (a-x[0]) - 4 * b * x[0] * (x[1]-x[0]**2),\
			2 * b * (x[1]-x[0]**2)\
		])
	if derivatives[2]:
		values["Hessian"] = np.array([\
			[2 - 4 * b * (x[1] - 3 * x[0]**2), -4 * b * x[0]],\
			[-4 * b * x[0], 2 * b]\
		])
    
	return values
