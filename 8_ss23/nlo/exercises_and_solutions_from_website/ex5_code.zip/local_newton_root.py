# This module implements the newton-raphson method for root finding problems

import numpy as np

def newton_root(f, x0, preconditioner, step_length_rule = lambda phi, reusables: (1,0), parameters = {}):
	"""
	Solve a root finding problem

	f(x) = 0 for f: R^n -> R^n

	using local newton's method.

	Accepts:  
		               f: the function whose root should be computed
		              x0: the initial guess (list or numpy array with ndim == 1)
		step_length_rule: a step length computation function (default is always one)
		  preconditioner: a symmetric positive definite matrix (numpy array with ndim == 2) used to measure the norms
		      parameters: optional parameters (dictionary);
		                  the following key/value pairs are evaluated:
		                                ["atol_x"]: absolute stopping tolerance for the preconditioner norm of updates in x
		                                ["rtol_x"]: relative stopping tolerance for the preconditioner norm of updates in x
		                                ["atol_f"]: absolute stopping tolerance for the preconditioner norm of the residual
		                                ["rtol_f"]: relative stopping tolerance for the preconditioner norm of the residual
		                        ["max_iterations"]: maximum number of iterations
		                             ["verbosity"]: "verbose" or "quiet"
		                          ["keep_history"]: whether or not to store the iteration history (True or False) 
    
	Returns: 
		       result: a dictionary containing 
		     solution: final iterate
		norm_residual: preconditioner-induced norm of final objective gradient
		         iter: number of iterations performed
		     exitflag: flag encoding why the algorithm terminated
		               0: stopping tolerance described by atol_x, rtol_x reached
		               1: stopping tolerance described by atol_f, rtol_f reached
		               2: maximum number of iterations reached
		      history: a dictionary for the history of the run containing
		                            iterates: the iterates x
		                      residual_norms: the preconditioner norms of the objective function values
		                       steps_lengths: the step lengths chosen by the step length rule
	"""
	# Define computation of the squared preconditioner norm
	def norm2(d): return d.dot(preconditioner.dot(d))
  
	# Define an output function that will be used to print information on the state of the iteration
	def print_header():
		print('---------------------------------------------------------')
		print(' ITER     NORM_RES       NORM_D        STEP  NRM_RES_CHNG')
		print('---------------------------------------------------------')

	# Define exitflags that will be printed when the algorithm terminates
	exitflag_messages = [
		'Relative and absolute tolerances on the norm of the update are satisfied.',
		'Relative and absolute tolerances on the norm of the residual are satisfied.',
		'Maximum number of optimization steps is reached.',
		'Could not compute direction.',
		]

	# Get the algorithmic parameters, using defaults if missing
	atol_x = parameters.get("atol_x", 1e-6)
	rtol_x = parameters.get("rtol_x", 1e-6)
	atol_f = parameters.get("atol_f", 1e-6)
	rtol_f = parameters.get("rtol_f", 1e-6)
	max_iterations = parameters.get("max_iterations", 1e2)
	verbosity = parameters.get("verbosity", "quiet")
	keep_history = parameters.get("keep_history", False)

	# Initialize the iterates, counters etc.
	x = x0
	iter = 0
	exitflag = None
  
	# Initialize dummy values pertaining to the previous iterate
	x_old = None
	norm_residual_old = None
  
	# Prepare a dictionary to store the history
	if keep_history:
		history = {
			"iterates" : [],
			"residual_norms" : [],
			"step_lengths" : [],
			}

	# Perform Newton steps
	while exitflag is None:
		# Record the current iterate
		if keep_history: history["iterates"].append(x)

		# Dump some output
		if verbosity == 'verbose':
			if (iter%10 == 0): print_header()
			print(' %4d  ' % (iter), end = '')

		# Stop when the maximum number of iterations has been reached
		if iter >= max_iterations:
			exitflag = 2
			break

		# Compute the function value and derivative at current iterate
		values = f(x, derivatives = [True, True])
		residual = values["function"]
		derivative = values["derivative"]

		# Compute residual norm
		try:
			norm_residual = np.sqrt(norm2(residual))
		except:
			raise ValueError('Your preconditioner appears not to be positive definite.')

		# Record the current value of the residual norm
		if keep_history: history["residual_norms"].append(norm_residual)

		# Dump some output
		if verbosity == 'verbose': print('%11.4e  ' % (norm_residual), end = '')

		# Remember the norm of the initial residual
		if (iter == 0): initial_norm_residual = norm_residual

		# Stop when the stopping tolerance on the norm of the gradient has been reached
		if norm_residual <= atol_f + rtol_f * initial_norm_residual:
			exitflag = 1
			break

		# Evaluate the change in the residual values
		try:
			delta_norm_res = norm_residual - norm_residual_old
		except:
			delta_norm_res = np.inf

		# Evaluate the norm of the update step
		try:
			norm_delta_x = np.sqrt(norm2(x - x_old))
		except:
			norm_delta_x = np.inf

		# Evaluate the norm of the direction
		try:
			norm_d = np.sqrt(norm2(d))
		except:
			norm_d = np.inf

		# Evaluate the reference values for relative tolerances
		try:
			norm_x_old = np.sqrt(norm2(x_old))
		except:
			norm_x_old = np.inf

		# Dump some output
		if verbosity == 'verbose':
			try:
				print('%11.4e  %11.4e  %11.4e' % (norm_d, t, delta_norm_res))
			except:
				print('%11.4e  %11.4e  %11.4e' % (norm_d, np.inf, delta_norm_res))

		# Stop when the stopping tolerance on the norm of the update step has been reached
		if norm_delta_x < atol_x + rtol_x * norm_x_old:
			exitflag = 0
			break

		# Compute the update direction
		try:
			d = -np.linalg.solve(np.atleast_2d(derivative), residual)
		except:
			exitflag = 4
			break

		# Prepare the line search function using the chain rule
		def phi(t, derivatives):
			values = f(x + t * d, derivatives)
			if derivatives[1]:
				values["derivative"] = values["derivative"]@d
			return values

		# Prepare some data to pass down to the step length computation rule
		reusables = {
			"phi0" : residual,
			"dphi0" : derivative
		}

		# Evaluate the step length t using the step length rule
		t, t_exitflag = step_length_rule(phi, reusables)

		# Check whether of not the step length was computed succesfully
		if t_exitflag: raise AssertionError('Step length was not computed succesfully.')

		# Record the chosen step length 
		if keep_history: history["step_lengths"].append(t)

		# Save the current iterate and associated residual norm for next iteration
		x_old = x
		norm_residual_old = norm_residual

		# Update the iterate and increase the counter
		x = x + t * d
		iter = iter + 1
		
	# Dump some output
	if verbosity == 'verbose':
		print('\n\nLocal newton is exiting with flag %d.\n' %(exitflag) + str(exitflag_messages[exitflag])+'\n' )
	
	# Create and populate the result to be returned
	result = {
		"solution" : x,
		"norm_residual" : norm_residual,
		"iter" : iter,
		"exitflag" : exitflag
	}
	
	# Assign the history to the result if required
	if keep_history:
		result["history"] = history
	
	return result
