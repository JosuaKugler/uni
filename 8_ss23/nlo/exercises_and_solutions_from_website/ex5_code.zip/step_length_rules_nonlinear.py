# This module collects various step length computation schemes for iterative
# line search optimization algorithms applied in nonlinear problems.

import numpy as np

def armijo_backtracking(phi, reusables = {}, initial_step_length = None, parameters = {}):
  """
  Compute a step length t via backtracking satisfying the Armijo condition 
  for the function phi, i.e.,

    phi(t) <= phi(0) + sigma * t * dphi(0) 

  where dphi(0) is the derivative of phi at t = 0.

  Accepts: 
           phi: evaluates the function the line search is performed on
     reusables: additional information that may be provided to the method (dictionary);
                the following key/value pairs are evaluated:
                   ["phi0"]: the value of phi at t = 0 (scalar)
                  ["dphi0"]: the value of the derivative of phi at t = 0 (scalar)
     parameters: method parameters sigma, betas, initial_t, verbosity, max_iterations

  Returns:
            t: step length satisfying the armijo condition (provided it is quadratic)
     exitflag: flag encoding why the line search terminated
                 0: success
                 1: maximum number of iterations reached
                 2: trial step length became too small
  """

  def print_header():
    print('--------------------------------------------------------------------')
    print(' ARMIJO:     ITER          STEP      OBJCHNG           ')
    print('--------------------------------------------------------------------')
  
  # Get the line search parameters, using defaults if missing
  sigma = parameters.get("sigma", 0.01)
  betas = np.array(parameters.get("betas", [0.5]))
  verbosity = parameters.get("verbosity", "quiet")
  max_iterations = parameters.get("max_iterations", 1e4)

  # Get initial step length
  if initial_step_length:
    initial_t = initial_step_length
  else:
    initial_t = parameters.get("initial_step_length", 1.0)

  # Figure out whether to interpolate
  if len(betas) == 1:
    interpolate = False
  else:
    interpolate = True

  # Extract or compute required data for checking armijo condition
  phi0 = reusables.get("phi0", phi(0, derivatives = [True, False, False])["function"]) or\
    phi(0, derivatives[True,False,False])["function"]
  dphi0 = reusables.get("dphi0", phi(0, derivatives = [False, True, False])["derivative"]) or\
    phi(0, derivatives[False,True,False])["derivative"]
  
  if dphi0 >= 0:
    raise(InputError('The function phi is expected to be first order decreasing at zero.'))
  
  # Initialize the step length and counter
  t = initial_t
  iter = 0
  exitflag = None
    
  # Perform the backtracking search until one of the termination criteria is met
  while exitflag is None:

    # Evaluate the value of phi at the current trial step length and the amount of descent
    phi_trial = phi(t, derivatives = [True, False, False])["function"]
    delta_phi = phi_trial - phi0
    
    # Dump some output
    if verbosity == 'verbose':
      if (iter%10 == 0): print_header()
      print('             %4d   %11.4e  %11.4e  \n' % (iter, t, delta_phi))
    
    # Verify the Armijo condition
    if delta_phi <= sigma * t * dphi0:
      exitflag = 0
      break
    # Stop when the maximum number of iterations has been reached
    elif iter >= max_iterations:
      exitflag = 1
      print('Warning: Armijo is stopping because the maximum number of iterations is reached.\n')
      break
    # Stop when the function appears locally constant and the initial step length has decreased significantly
    elif (delta_phi == 0) and (t / initial_t < 1e-12): 
      exitflag = 2                               
      if verbosity == 'verbose':
        print('Warning: Armijo is stopping because the function appears locally constant.\n')
      break
    
    # If we did not stop, either backtrack immediately or interpolate and backtrack

    if interpolate:
      # compute the minimizer of the quadratic hermite interpolating polynomial for phi0, dphi0 and phi(t)
      t_min_quad = - (dphi0 * t**2)/(2*(phi_trial - phi0 - dphi0*t))

      # clip the minimizer
      t = min(max(t_min_quad,np.min(betas)*t),np.max(betas)*t)
    else:
      # Reduce the trial step size
      t = betas[0] * t

    # Increase the counter
    iter = iter + 1
    
  # Check whether the step length is in fact positive
  if t < 0.0:
    raise ValueError('Armijio is returning a negative step length.')
  else:
    return t, exitflag
